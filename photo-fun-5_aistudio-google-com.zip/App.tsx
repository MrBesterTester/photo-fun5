import React, { useState, useCallback, useEffect } from 'react';
import { Header } from './components/Header';
import { ImageUploader } from './components/ImageUploader';
import { ImagePreview } from './components/ImagePreview';
import { ChatInterface } from './components/ChatInterface';
import { Message, Role } from './types';
import { editImageWithGemini } from './services/geminiService';
import { ERROR_MESSAGES } from './constants';

const MAX_SESSION_REQUESTS = 10;

const App: React.FC = () => {
  const [apiKeyVerified, setApiKeyVerified] = useState(false);
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [currentImage, setCurrentImage] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [requestCount, setRequestCount] = useState(0);

  useEffect(() => {
    const checkKey = async () => {
      // @ts-ignore
      if (window.aistudio && window.aistudio.hasSelectedApiKey) {
        // @ts-ignore
        const hasKey = await window.aistudio.hasSelectedApiKey();
        setApiKeyVerified(hasKey);
      } else {
        setApiKeyVerified(true);
      }
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    // @ts-ignore
    if (window.aistudio && window.aistudio.openSelectKey) {
      // @ts-ignore
      await window.aistudio.openSelectKey();
      setApiKeyVerified(true);
    }
  };

  const handleImageSelect = useCallback((base64: string) => {
    setOriginalImage(base64);
    setCurrentImage(base64);
    setMessages([{
      id: 'init',
      role: Role.MODEL,
      text: "Awesome photo! Select a style or type your request below.",
      timestamp: Date.now()
    }]);
  }, []);

  const handleReset = useCallback(() => {
    if (originalImage) setCurrentImage(originalImage);
  }, [originalImage]);

  const handleSendMessage = async (text: string) => {
    if (requestCount >= MAX_SESSION_REQUESTS) {
       setMessages(prev => [...prev, { id: Date.now().toString(), role: Role.MODEL, text: ERROR_MESSAGES.quota, timestamp: Date.now() }]);
       return;
    }

    setMessages(prev => [...prev, { id: Date.now().toString(), role: Role.USER, text, timestamp: Date.now() }]);
    setIsProcessing(true);
    setRequestCount(prev => prev + 1);

    try {
      const { image, text: responseText } = await editImageWithGemini(currentImage!, text);
      if (image) setCurrentImage(image);
      setMessages(prev => [...prev, { id: Date.now().toString(), role: Role.MODEL, text: responseText || "Transformation complete!", timestamp: Date.now() }]);
    } catch (error: any) {
      const err = error.toString();
      if (err.includes("Requested entity was not found")) {
        setApiKeyVerified(false);
      } else {
        setMessages(prev => [...prev, { id: Date.now().toString(), role: Role.MODEL, text: ERROR_MESSAGES.generic, timestamp: Date.now() }]);
      }
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <Header onChangeKey={handleSelectKey} />
      <main className="flex-1 overflow-hidden p-4 md:p-6 lg:p-10 flex flex-col lg:flex-row gap-6">
          <div className="flex-1 min-h-[400px] lg:h-full bg-slate-900 rounded-3xl overflow-hidden border border-white/5">
            {!currentImage ? (
              <ImageUploader onImageSelect={handleImageSelect} />
            ) : (
              <ImagePreview 
                originalImage={originalImage!}
                currentImage={currentImage}
                isProcessing={isProcessing}
                onReset={handleReset}
              />
            )}
          </div>
          <div className="w-full lg:w-[450px] h-full">
             <ChatInterface 
                messages={messages}
                isProcessing={isProcessing}
                onSendMessage={handleSendMessage}
             />
          </div>
      </main>
    </div>
  );
};

export default App;